#!/usr/bin/env python

__author__='Alvaro Bautista'

import base64
import httplib
import getpass
from urllib import urlencode
import cgi

# Enter here your user and pass if you don't want script ask them everytime
user = "youruser"
pswd = "yourpass"

def twitter_request(uribase, status):
    global user, pswd
    
    if user == "":
        user = raw_input("Username: ")

    if pswd == "":
        pswd = getpass.getpass()

    print 
    auth = base64.encodestring(user + ":" + pswd)
    head = {"Authorization":"Basic %s" % auth}

    if test_credentials(head):    # Check login and pass

        conn = httplib.HTTPConnection("twitter.com")

        uri = uribase + urlencode({'status':status})

        try:
            conn.request('POST',uri,None,head)
        except Exception, e:
            return None
        
        try:
            res = conn.getresponse()
            print 'Done: Status changed to "' + status +'"'
        except Exception, e:
            print "Connection error. Maybe you have to check user and password."
            return None
        
    else:
        print "Authentication failed. Check your login and password."

def test_credentials (head) :

        method = 'HEAD'
        conn = httplib.HTTPConnection("twitter.com")

        try :
            conn.request(method, '/statuses/friends.xml', None, head)
        except Exception, e:
             print "Unable to connect to test auth, %s" % e
             return False

        try :
            res = conn.getresponse()
        except Exception, e :
            #print "Unable to read auth response : %s" % e
            return False
        
        if res.status != 200 :
            #print "Auth failed with status %s" % res.status
            return False

        return True

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print "Use: ", sys.argv[0], '"Text to post"'
    else:
        twitter_request('/statuses/update.xml?', sys.argv[1])
